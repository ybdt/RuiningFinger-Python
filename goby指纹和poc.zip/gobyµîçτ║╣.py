import re
import binascii
import json
import mmap
import orjson

from bs4 import BeautifulSoup


def getgobyinfo():
    with open("goby-cmd", 'rb') as f:
        data = f.read()
        stasrt = data.index(b"\x7B\x22\x70\x72\x6F\x64\x75\x63\x74\x22\x3A\x22\x69\x4B\x75\x61")
        end = data.index(b"\x0A" + b"\x00" * 16, stasrt)
        datalist = data[stasrt:end].split(b"\n")
        result = []
        for item in datalist:
            result.append(json.loads(item.decode("utf-8")))
        with open("goby.json", "w") as d:
            json.dump(result, d, ensure_ascii=False)  #
        print("goby指纹查找完成！", len(result))


def getgobypocjson():
    filename = r"goby-cmd"
    with open(filename, 'rb') as stream:
        mmapped_data = mmap.mmap(stream.fileno(), 0, access=mmap.ACCESS_READ)
        # 从内存映射对象中读取数据
        # 要搜索的起始和结束二进制数据
        start_data = b"\x7B\x0A\x20\x20\x22\x4E\x61\x6D\x65\x22"
        start_data2 = b"\x7B\x0A\x20\x20\x20\x20\x20\x20\x22\x4E\x61\x6D\x65\x22\x3A\x20\x22"
        end_data = b"\x0A\x7D"
        # 初始化查找的起始位置
        result = []
        start_index = 0
        print("开始查找数据...")
        while start_index != -1:
            # 使用 find 方法查找起始位置
            start_index = mmapped_data.find(start_data, start_index)
            # 查找结束位置
            end_index = mmapped_data.find(end_data, start_index)
            if end_index != -1:
                # 从起始位置到结束位置获取数据块
                data_block = mmapped_data[start_index:end_index + len(end_data)]
                if b'"Description"' in data_block:
                    result.append(json.loads(data_block.decode("utf-8")))
                # 更新查找的起始位置
                start_index = end_index + len(end_data)
            else:
                # 如果未找到结束数据，退出循环
                break
        start_index = 0
        while start_index != -1:
            start_index = mmapped_data.find(start_data2, start_index)
            end_index = mmapped_data.find(end_data, start_index)
            if end_index != -1:
                # 从起始位置到结束位置获取数据块
                data_block = mmapped_data[start_index:end_index + len(end_data)]
                if 'SAP NetWeaver Authentication Bypass (CVE-2020-6287) RECON' in data_block.decode("utf-8"):
                    result.append(json.loads(data_block.decode("utf-8").split("=3D=00a")[1]))
                elif '"Description"' in data_block.decode("utf-8"):
                    try:
                        result.append(json.loads(data_block.decode("utf-8")))
                    except Exception as e:
                        pass
                start_index = end_index + len(end_data)
            else:
                break
        mmapped_data.close()
    with open("gobypoc.json", "w") as d:
        json.dump(result, d, ensure_ascii=False)
    print("goby poc查找完成！", len(result))


if __name__ == '__main__':
    getgobypocjson()
    getgobyinfo()
